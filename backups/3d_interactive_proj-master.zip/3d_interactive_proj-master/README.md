# 3d_interactive_proj
Smart System Competition Proj

7월 28일 GITHUB 시작

8월 목표: 제스쳐 인식 완성, 프레임 완성

./src 소스 파일
./include 헤더 파일

사전 설치

Point Cloud Library

Xdotool
